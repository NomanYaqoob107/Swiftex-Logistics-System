#include <iostream>
#include <string>
#include <climits>
#include <iomanip>
#include <sstream>
#include <ctime>
#include <fstream>

using namespace std;

// ==========================================
// 0. UI HELPER & CONSTANTS
// ==========================================

void printLine(int width = 95)
{
    cout << setfill('-') << setw(width) << "" << setfill(' ') << endl;
}

void printDoubleLine(int width = 95)
{
    cout << setfill('=') << setw(width) << "" << setfill(' ') << endl;
}

void printTitle(string title)
{   
    int width = 95;
    printDoubleLine(width);
    int padding = (width - title.length() - 4) / 2;
    cout << "|| " << setw(padding) << "" << title << setw(padding) << "" << " ||" << endl;
    printDoubleLine(width);
}

void printBrandHeader()
{
    cout << endl;
    cout << "  _______________________________________________________________________________  " << endl;
    cout << "                                                                                " << endl;
    cout << "               S W I F T E X   L O G I S T I C S   S Y S T E M   " << endl;
    cout << "  _______________________________________________________________________________ " << endl;
}

int getValidInput(string prompt)
{
    int value;
    while (true)
    {
        cout << prompt;
        cin >> value;
        if (cin.fail())
        {
            cin.clear();
            cin.ignore(INT_MAX, '\n');
            cout << " Error: Please enter a valid number." << endl;
        }
        else
        {
            cin.ignore(INT_MAX, '\n');
            return value;
        }
    }
}

// ==========================================
// CORE DATA OBJECTS
// ==========================================

// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                    MODULE 1: PARCEL MANAGEMENT SYSTEM                        ║
// ║                           (Member 1 Responsibility)                          ║
// ╠═══════════════════════════════════════════════════════════════════════════════╣
// ║ ABSTRACTION: This module encapsulates all parcel-related operations          ║
// ║                                                                               ║
// ║ DATA STRUCTURES:                                                              ║
// ║   • Parcel Class - Core entity with status, weight, priority                 ║
// ║   • ParcelNode - Node for doubly linked list                                 ║
// ║   • ParcelLinkedList - Doubly linked list for parcel storage                 ║
// ║   • TrackingTable - Hash table for O(1) parcel lookup                        ║
// ║                                                                               ║
// ║ INTERFACE FUNCTIONS:                                                          ║
// ║   • Parcel(id, src, dest, weight, priority) - Constructor                    ║
// ║   • addEvent(event) - Add to audit trail                                     ║
// ║   • printRow() - Display parcel in table format                              ║
// ║   • ParcelLinkedList::append() - Add parcel to list                          ║
// ║   • ParcelLinkedList::search(id) - Find parcel by ID                         ║
// ║   • TrackingTable::insert() - Add to hash table                              ║
// ║   • TrackingTable::search() - O(1) lookup by ID                              ║
// ║                                                                               ║
// ║ MENU OPTIONS: [1] New Parcel, [2] Track, [9] All, [12] Missing, [13] Update  ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝


class Parcel
{
public:
    int id;
    string source;
    string destination;
    int weight;
    int priority;
    string status;
    double shippingCost;
    string historyLog;

    // FIELDS FOR TIME & FAILURE LOGIC
    time_t dispatchTime;  // When truck left (0 if not started)
    int deliveryDuration; // In seconds (Distance / Speed)
    bool willFail;        // Predetermined fate if path was blocked
    
    // NEW: MISSING PARCEL DETECTION
    bool isMissing;       // True if parcel is lost/missing
    time_t lastSeenTime;  // Last timestamp parcel was tracked
    
    // NEW: WAREHOUSE STAGING
    string warehouseStage; // "Receiving", "Sorting", "Loading", or "Dispatched"

    Parcel(int pid, string src, string dest, int w, int p)
        : id(pid), source(src), destination(dest), weight(w), priority(p), status("Processing"),
          dispatchTime(0), deliveryDuration(0), willFail(false), isMissing(false), 
          lastSeenTime(time(0)), warehouseStage("Receiving")
    {
        shippingCost = 5.0 + (2.0 * w) + (p == 1 ? 10.0 : 0.0);
        historyLog = "Created at Hub (" + src + "). Stage: Receiving";
    }

    Parcel() : dispatchTime(0), deliveryDuration(0), willFail(false), isMissing(false), 
               lastSeenTime(0), warehouseStage("Receiving") {}

    void addEvent(string event)
    {
        historyLog += "\n          " + event;
    }

    void printRow()
    {
        cout << "| " << left << setw(6) << id
             << "| " << setw(15) << source
             << "| " << setw(15) << destination
             << "| " << setw(8) << (to_string(weight) + "kg")
             << "| " << setw(10) << (priority == 1 ? "High" : (priority == 2 ? "Med" : "Low"))
             << "| " << setw(14) << status
             << "| " << "Rs:" << fixed << setprecision(2) << setw(8) << shippingCost << "|" << endl;
    }
};

class Edge
{
    public:
    int destCityID;
    int weight;         // Current Weight (affected by traffic)
    int originalWeight; // Base Distance
    int status;         // 1=Normal, 2=Traffic, 3=Blocked

    Edge(int d, int w, int ow, int s) : destCityID(d), weight(w), originalWeight(ow), status(s) {}
};

// ==========================================
// DATA STRUCTURES
// ==========================================

class ParcelNode
{
public:
    Parcel *data;
    ParcelNode *next;
    ParcelNode *prev;
    ParcelNode(Parcel *val) : data(val), next(nullptr), prev(nullptr) {}
};

class EdgeNode
{
public:
    Edge data;
    EdgeNode *next;
    EdgeNode(Edge val) : data(val), next(nullptr) {}
};

class ParcelLinkedList
{
public:
    ParcelNode *head;
    ParcelNode *tail;
    int listSize;

    ParcelLinkedList() : head(nullptr), tail(nullptr), listSize(0) {}

    void append(Parcel *val)
    {
        ParcelNode *newNode = new ParcelNode(val);
        if (!head)
        {
            head = tail = newNode;
        }
        else
        {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        listSize++;
    }

    Parcel *removeFront()
    {
        if (!head)
            return nullptr;
        ParcelNode *temp = head;
        Parcel *val = temp->data;
        head = head->next;
        if (head)
            head->prev = nullptr;
        else
            tail = nullptr;
        delete temp;
        listSize--;
        return val;
    }

    Parcel *removeBack()
    {
        if (!tail)
            return nullptr;
        ParcelNode *temp = tail;
        Parcel *val = temp->data;
        if (head == tail)
        {
            head = tail = nullptr;
        }
        else
        {
            tail = tail->prev;
            tail->next = nullptr;
        }
        delete temp;
        listSize--;
        return val;
    }

    Parcel *search(int id)
    {
        ParcelNode *curr = head;
        while (curr)
        {
            if (curr->data->id == id)
                return curr->data;
            curr = curr->next;
        }
        return nullptr;
    }

    bool isEmpty() { return head == nullptr; }
};

class EdgeLinkedList
{
public:
    EdgeNode *head;
    EdgeLinkedList() : head(nullptr) {}

    void append(Edge val)
    {
        EdgeNode *newNode = new EdgeNode(val);
        if (!head)
        {
            head = newNode;
        }
        else
        {
            EdgeNode *temp = head;
            while (temp->next)
                temp = temp->next;
            temp->next = newNode;
        }
    }

    void updateStatus(int destID, int newStatus, int newWeight)
    {
        EdgeNode *curr = head;
        while (curr)
        {
            if (curr->data.destCityID == destID)
            {
                curr->data.status = newStatus;
                curr->data.weight = newWeight;
                return;
            }
            curr = curr->next;
        }
    }

    EdgeNode *find(int destID)
    {
        EdgeNode *curr = head;
        while (curr)
        {
            if (curr->data.destCityID == destID)
                return curr;
            curr = curr->next;
        }
        return nullptr;
    }
};

// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                  MODULE 2: TRUCK & WAREHOUSE OPERATIONS                      ║
// ║                           (Member 2 Responsibility)                          ║
// ╠═══════════════════════════════════════════════════════════════════════════════╣
// ║ ABSTRACTION: This module encapsulates truck loading and warehouse sorting    ║
// ║                                                                               ║
// ║ DATA STRUCTURES:                                                              ║
// ║   • CustomQueue - FIFO queue for truck loading order                         ║
// ║   • CustomStack - LIFO stack for undo operations                             ║
// ║   • ParcelHeap - Priority queue with multi-key sorting                       ║
// ║                                                                               ║
// ║ INTERFACE FUNCTIONS:                                                          ║
// ║   • CustomQueue::enqueue() - Add parcel to truck                             ║
// ║   • CustomQueue::dequeue() - Remove parcel from truck                        ║
// ║   • CustomStack::push/pop() - Undo stack operations                          ║
// ║   • ParcelHeap::insert() - Add to priority queue                             ║
// ║   • ParcelHeap::extractMin() - Get highest priority parcel                   ║
// ║   • ParcelHeap::displayPriorityQueue() - View sorted queue                   ║
// ║                                                                               ║
// ║ SORTING: Priority (1>2>3) → Weight (heavy first) → Distance (short first)   ║
// ║                                                                               ║
// ║ MENU OPTIONS: [3] Load Truck, [4] Dispatch, [5] Undo Load, [8] Priority Q    ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

class CustomQueue
{
    ParcelLinkedList list;
    const int MAX_CAPACITY = 5;

public:
    void enqueue(Parcel *p) { list.append(p); }
    Parcel *dequeue() { return list.removeFront(); }
    Parcel *removeLast() { return list.removeBack(); }
    bool isEmpty() { return list.isEmpty(); }
    int getSize() { return list.listSize; }
    bool isFull() { return list.listSize >= MAX_CAPACITY; }
    int getCapacity() { return MAX_CAPACITY; }

    void display()
    {
        if (isEmpty())
        {
            cout << "  Truck is empty" << endl;
            return;
        }
        cout << "\n Truck Load: " << list.listSize << "/" << MAX_CAPACITY << endl;
        printLine();
        cout << "| " << left << setw(6) << "ID"
             << "| " << setw(15) << "SOURCE"
             << "| " << setw(15) << "DEST"
             << "| " << setw(8) << "WEIGHT"
             << "| " << setw(10) << "PRIORITY"
             << "| " << setw(14) << "STATUS"
             << "| " << setw(9) << "COST" << "|" << endl;
        printLine();
        ParcelNode *curr = list.head;
        while (curr)
        {
            curr->data->printRow();
            curr = curr->next;
        }
        printLine();
    }
};

class CustomStack
{
    ParcelLinkedList list;

public:
    void push(Parcel *p) { list.append(p); }
    Parcel *pop() { return list.removeBack(); }
    bool isEmpty() { return list.isEmpty(); }
    void clear()
    {   
        while (!isEmpty())
            pop();
    }
};

class ParcelHeap
{
private:
    Parcel *heapArray[200];
    int currentSize;

    void heapifyUp(int index)
    {
        int parent = (index - 1) / 2;
        if (index > 0 && compareParcel(heapArray[index], heapArray[parent]))
        {
            swap(heapArray[index], heapArray[parent]);
            heapifyUp(parent);
        }
    }
    
    // NEW: Multi-key comparison helper
    // Returns true if p1 should come before p2
    // Priority: 1 (High) > 2 (Med) > 3 (Low)
    // Then by weight (heavier first for efficiency)
    // Then by distance (shorter first)
    bool compareParcel(Parcel* p1, Parcel* p2)
    {
        // First compare by priority (lower number = higher priority)
        if (p1->priority != p2->priority)
            return p1->priority < p2->priority;
        
        // If same priority, compare by weight (heavier first)
        if (p1->weight != p2->weight)
            return p1->weight > p2->weight;
        
        // If same weight, compare by distance (we'll use delivery duration as proxy)
        return p1->deliveryDuration < p2->deliveryDuration;
    }

    void heapifyDown(int index)
    {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < currentSize && compareParcel(heapArray[left], heapArray[smallest]))
            smallest = left;
        if (right < currentSize && compareParcel(heapArray[right], heapArray[smallest]))
            smallest = right;

        if (smallest != index)
        {
            swap(heapArray[index], heapArray[smallest]);
            heapifyDown(smallest);
        }
    }

public:
    ParcelHeap() : currentSize(0) {}

    void insert(Parcel *p)
    {
        if (currentSize >= 200)
            return;
        heapArray[currentSize] = p;
        heapifyUp(currentSize);
        currentSize++;
    }

    Parcel *extractMin()
    {
        if (currentSize == 0)
            return nullptr;
        Parcel *min = heapArray[0];
        heapArray[0] = heapArray[currentSize - 1];
        currentSize--;
        heapifyDown(0);
        return min;
    }

    int getSize() { return currentSize; }
    bool isEmpty() { return currentSize == 0; }
    Parcel *peek() { return currentSize == 0 ? nullptr : heapArray[0]; }
    
    // NEW: Display priority queue contents
    void displayPriorityQueue()
    {
        if (currentSize == 0)
        {
            cout << "  Priority queue is empty." << endl;
            return;
        }
        
        cout << "\n Warehouse Priority Queue (" << currentSize << " parcels):" << endl;
        cout << " Sorted by: Priority (1=High, 2=Med, 3=Low) -> Weight -> Distance" << endl;
        printLine();
        cout << "| " << left << setw(6) << "ID"
             << "| " << setw(15) << "SOURCE"
             << "| " << setw(15) << "DEST"
             << "| " << setw(8) << "WEIGHT"
             << "| " << setw(10) << "PRIORITY"
             << "| " << setw(14) << "STATUS"
             << "| " << setw(9) << "COST" << "|" << endl;
        printLine();
        
        // Display parcels in heap order (already sorted by priority)
        for (int i = 0; i < currentSize; i++)
        {
            heapArray[i]->printRow();
        }
        printLine();
        
        // Show next parcel to be loaded
        if (currentSize > 0)
        {
            cout << "\n NEXT TO LOAD: Parcel #" << heapArray[0]->id 
                 << " (Priority: " << heapArray[0]->priority 
                 << ", Weight: " << heapArray[0]->weight << "kg)" << endl;
        }
    }
};

// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                   MODULE 3: ROUTING & NAVIGATION SYSTEM                      ║
// ║                           (Member 3 Responsibility)                          ║
// ╠═══════════════════════════════════════════════════════════════════════════════╣
// ║ ABSTRACTION: This module encapsulates all graph-based routing operations     ║
// ║                                                                               ║
// ║ DATA STRUCTURES:                                                              ║
// ║   • Edge - Road connection with weight and status                            ║
// ║   • EdgeLinkedList - Adjacency list for each city                            ║
// ║   • CityGraph - Complete city network with roads                             ║
// ║   • PathResult - Single path result container                                ║
// ║   • RouteOption - K-shortest paths result container                          ║
// ║                                                                               ║
// ║ INTERFACE FUNCTIONS:                                                          ║
// ║   • CityGraph::addCity() - Add new city node                                 ║
// ║   • CityGraph::addRoad() - Connect two cities                                ║
// ║   • CityGraph::calculateRoute() - Dijkstra's shortest path                   ║
// ║   • CityGraph::calculateKShortestPaths() - Find K alternative routes         ║
// ║   • CityGraph::printNetwork() - Display city map                             ║
// ║                                                                               ║
// ║ ALGORITHMS: Dijkstra's Shortest Path O(V²), K-Shortest Paths O(K×V²)         ║
// ║                                                                               ║
// ║ MENU OPTIONS: [6] Route Info, [7] K-Shortest Paths                           ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

class PathResult
{
    public:
    int distance;
    string pathString;
    bool isBlocked;
    bool hasTraffic; // Detects if path has heavy traffic
};

// NEW: K-SHORTEST PATHS SUPPORT
class RouteOption
{
public:
    int distance;
    string pathString;
    bool isBlocked;
    bool hasTraffic;
    int ranking; // 1st, 2nd, 3rd shortest
    
    RouteOption() : distance(INT_MAX), isBlocked(false), hasTraffic(false), ranking(0) {}
};

// NEW: RIDER CLASS FOR ASSIGNMENT LOGIC
class Rider
{
public:
    int id;
    string name;
    int currentLoad;      // Number of parcels currently assigned
    int maxCapacity;      // Maximum parcels they can carry
    int totalWeight;      // Total weight currently carrying
    int maxWeight;        // Maximum weight capacity
    bool isAvailable;
    
    Rider() : id(0), name(""), currentLoad(0), maxCapacity(5), 
              totalWeight(0), maxWeight(50), isAvailable(true) {}
    
    Rider(int rid, string rname, int cap = 5, int wCap = 50) 
        : id(rid), name(rname), currentLoad(0), maxCapacity(cap),
          totalWeight(0), maxWeight(wCap), isAvailable(true) {}
    
    bool canAccept(int weight)
    {
        return isAvailable && currentLoad < maxCapacity && (totalWeight + weight) <= maxWeight;
    }
    
    void assignParcel(int weight)
    {
        currentLoad++;
        totalWeight += weight;
        if (currentLoad >= maxCapacity)
            isAvailable = false;
    }
    
    void releaseParcel(int weight)
    {
        if (currentLoad > 0) currentLoad--;
        totalWeight -= weight;
        if (totalWeight < 0) totalWeight = 0;
        if (currentLoad < maxCapacity)
            isAvailable = true;
    }
    
    void printRow()
    {
        cout << "| " << left << setw(4) << id
             << "| " << setw(15) << name
             << "| " << setw(12) << (to_string(currentLoad) + "/" + to_string(maxCapacity))
             << "| " << setw(15) << (to_string(totalWeight) + "kg/" + to_string(maxWeight) + "kg")
             << "| " << setw(10) << (isAvailable ? "Available" : "Full") << " |" << endl;
    }
};

// NEW: WAREHOUSE STAGING QUEUES
class WarehouseStages
{
public:
    CustomQueue receivingQueue;  // Newly arrived parcels
    CustomQueue sortingQueue;    // Being sorted
    CustomQueue loadingQueue;    // Ready for loading
    
    void moveToSorting(Parcel* p)
    {
        p->warehouseStage = "Sorting";
        p->addEvent("Moved to Sorting stage.");
        sortingQueue.enqueue(p);
    }
    
    void moveToLoading(Parcel* p)
    {
        p->warehouseStage = "Loading";
        p->addEvent("Moved to Loading stage.");
        loadingQueue.enqueue(p);
    }
    
    void displayStages()
    {
        cout << "\n Warehouse Stages Status:" << endl;
        printLine();
        cout << " Receiving Queue: " << receivingQueue.getSize() << " parcels" << endl;
        cout << " Sorting Queue:   " << sortingQueue.getSize() << " parcels" << endl;
        cout << " Loading Queue:   " << loadingQueue.getSize() << " parcels" << endl;
        printLine();
    }
};

// NEW: COMMAND PATTERN FOR UNDO/REDO
class Command
{
public:
    virtual ~Command() {}
    virtual void execute() = 0;
    virtual void undo() = 0;
    virtual string getDescription() = 0;
};

class LoadTruckCommand : public Command
{
    Parcel* parcel;
    CustomQueue* queue;
    ParcelHeap* heap;
    
public:
    LoadTruckCommand(Parcel* p, CustomQueue* q, ParcelHeap* h) 
        : parcel(p), queue(q), heap(h) {}
    
    void execute() override
    {
        parcel->status = "Loaded on Truck";
        parcel->addEvent("Loaded onto truck.");
        queue->enqueue(parcel);
    }
    
    void undo() override
    {
        queue->removeLast();
        parcel->status = "Processing";
        parcel->addEvent("Undo: Load reversed.");
        heap->insert(parcel);
    }
    
    string getDescription() override
    {
        return "Load Parcel #" + to_string(parcel->id);
    }
};

// Command History Manager
class CommandHistory
{
    Command* undoStack[50];
    Command* redoStack[50];
    int undoTop;
    int redoTop;
    
public:
    CommandHistory() : undoTop(-1), redoTop(-1) {}
    
    void execute(Command* cmd)
    {
        cmd->execute();
        if (undoTop < 49)
        {
            undoStack[++undoTop] = cmd;
            redoTop = -1; // Clear redo stack
        }
    }
    
    bool canUndo() { return undoTop >= 0; }
    bool canRedo() { return redoTop >= 0; }
    
    void undo()
    {
        if (canUndo())
        {
            Command* cmd = undoStack[undoTop--];
            cmd->undo();
            if (redoTop < 49)
                redoStack[++redoTop] = cmd;
        }
    }
    
    void redo()
    {
        if (canRedo())
        {
            Command* cmd = redoStack[redoTop--];
            cmd->execute();
            if (undoTop < 49)
                undoStack[++undoTop] = cmd;
        }
    }
    
    string getLastAction()
    {
        if (canUndo())
            return undoStack[undoTop]->getDescription();
        return "None";
    }
    
    void clear()
    {
        undoTop = -1;
        redoTop = -1;
    }
};


class CityGraph
{
private:
    struct CityNode
    {
        string name;
        EdgeLinkedList *adjList;
        CityNode() : name(""), adjList(new EdgeLinkedList()) {}
    };

    CityNode cities[50];
    int numCities;

public:
    CityGraph() : numCities(0) {}

    int getNumCities() { return numCities; }
    string getCityName(int id)
    {
        if (id >= 0 && id < numCities)
            return cities[id].name;
        return "";
    }
    EdgeLinkedList *getAdjList(int id) { return cities[id].adjList; }

    int getCityID(string cityName)
    {
        for (int i = 0; i < numCities; i++)
        {
            if (cities[i].name == cityName)
                return i;
        }
        return -1;
    }

    void addCity(int id, string name)
    {
        if (id < 50)
        {
            cities[id].name = name;
            if (id >= numCities)
                numCities = id + 1;
        }
    }

    void addRoad(int src, int dest, int weight, int status = 1)
    {
        if (src >= numCities || dest >= numCities)
            return;
        int w = weight;
        if (status == 2)
            w = weight * 2;
        if (status == 3)
            w = 999999;

        cities[src].adjList->append(Edge(dest, w, weight, status));
        cities[dest].adjList->append(Edge(src, w, weight, status));
    }

    void updateRoadStatus(int src, int dest, int status)
    {
        EdgeNode *edge = cities[src].adjList->find(dest);
        if (!edge)
            return;

        int origW = edge->data.originalWeight;
        int newW = origW;

        if (status == 2)
            newW = origW * 2;
        if (status == 3)
            newW = 999999;

        cities[src].adjList->updateStatus(dest, status, newW);
        cities[dest].adjList->updateStatus(src, status, newW);
    }

    void printNetwork()
    {
        cout << "\n"
             << " Network Map:" << endl;
        printLine();
        cout << "| " << setw(4) << "ID"
             << "| " << setw(20) << "CITY NAME"
             << "| " << "DIRECT CONNECTIONS (Status)" << endl;
        printLine();

        for (int i = 0; i < numCities; i++)
        {
            if (cities[i].name == "")
                continue;
            cout << "| " << setw(4) << i
                 << "| " << setw(20) << cities[i].name
                 << "| ";

            EdgeNode *curr = cities[i].adjList->head;
            if (!curr)
                cout << "None";
            while (curr)
            {
                cout << cities[curr->data.destCityID].name << "(" << curr->data.weight << "km";
                if (curr->data.status == 2)
                    cout << " TRAFFIC";
                if (curr->data.status == 3)
                    cout << " BLOCKED";
                cout << ") ";
                curr = curr->next;
            }
            cout << endl;
        }
        printLine();
    }

    void printDestinationsFrom(int sourceID)
    {
        cout << "\n"
             << " Available Destinations from " << cities[sourceID].name << ":" << endl;
        printLine();
        cout << "| " << setw(4) << "ID"
             << "| " << setw(20) << "CITY NAME" << endl;
        printLine();

        for (int i = 0; i < numCities; i++)
        {
            if (i == sourceID || cities[i].name == "")
                continue;
            cout << "| " << setw(4) << i
                 << "| " << setw(20) << cities[i].name << " |" << endl;
        }
        printLine();
    }

    bool isValidCity(int id)
    {
        return (id >= 0 && id < numCities && cities[id].name != "");
    }

    PathResult calculateRoute(int startNode, int endNode, bool useIgnoreBlockage = false)
    {
        PathResult result;
        result.distance = INT_MAX;
        result.isBlocked = false;
        result.hasTraffic = false;
        result.pathString = "";

        if (!isValidCity(startNode) || !isValidCity(endNode))
            return result;

        int dist[50];
        int parent[50];
        bool visited[50];

        for (int i = 0; i < 50; i++)
        {
            dist[i] = INT_MAX;
            visited[i] = false;
            parent[i] = -1;
        }
        dist[startNode] = 0;

        for (int count = 0; count < numCities; count++)
        {
            int u = -1;
            int minVal = INT_MAX;
            for (int i = 0; i < numCities; i++)
            {
                if (!visited[i] && dist[i] <= minVal && cities[i].name != "")
                {
                    minVal = dist[i];
                    u = i;
                }
            }
            if (u == -1)
                break;
            visited[u] = true;

            EdgeNode *curr = cities[u].adjList->head;
            while (curr)
            {
                int v = curr->data.destCityID;
                int weight;

                if (useIgnoreBlockage)
                {
                    weight = curr->data.originalWeight;
                }
                else
                {
                    weight = curr->data.weight;
                    if (curr->data.status == 3)
                        weight = 999999;
                }

                if (!visited[v] && dist[u] != INT_MAX && dist[u] + weight < dist[v])
                {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                }
                curr = curr->next;
            }
        }

        result.distance = dist[endNode];

        if (result.distance != INT_MAX && result.distance < 999999)
        {
            int pathStack[50];
            int pathSize = 0;

            int curr = endNode;
            while (curr != -1)
            {
                pathStack[pathSize++] = curr;
                // CHECK EDGE STATUS FOR WARNINGS
                if (parent[curr] != -1)
                {
                    int prev = parent[curr];
                    EdgeNode *e = cities[prev].adjList->find(curr);
                    if (e)
                    {
                        if (e->data.status == 2)
                            result.hasTraffic = true;
                        if (e->data.status == 3)
                            result.isBlocked = true;
                    }
                }
                curr = parent[curr];
            }

            for (int i = pathSize - 1; i >= 0; --i)
            {
                result.pathString += cities[pathStack[i]].name;
                if (i > 0)
                    result.pathString += " -> ";
            }
        }
        else
        {
            // Even if distance is huge, check if we found a path (meaning we went through a block)
            if (result.distance >= 999999 && parent[endNode] != -1)
            {
                result.isBlocked = true;
                result.pathString = "Blocked Path";
            }
            else
            {
                result.isBlocked = true;
                result.pathString = "No Path";
            }
        }

        return result;
    }
    
    // NEW: K-SHORTEST PATHS ALGORITHM
    // Returns up to K alternative routes sorted by distance
    void calculateKShortestPaths(int startNode, int endNode, RouteOption results[], int K = 3)
    {
        // Initialize all results
        for (int k = 0; k < K; k++)
        {
            results[k] = RouteOption();
            results[k].ranking = k + 1;
        }
        
        if (!isValidCity(startNode) || !isValidCity(endNode))
            return;
        
        // First, get the shortest path
        PathResult firstPath = calculateRoute(startNode, endNode, false);
        results[0].distance = firstPath.distance;
        results[0].pathString = firstPath.pathString;
        results[0].isBlocked = firstPath.isBlocked;
        results[0].hasTraffic = firstPath.hasTraffic;
        
        // For K=2 and K=3, we'll use a simplified approach:
        // Temporarily block edges in the shortest path and recalculate
        if (K >= 2 && firstPath.distance < 999999)
        {
            // Identify edges in shortest path
            int pathNodes[50];
            int pathLength = 0;
            
            // Parse path string to get node IDs (simplified - assumes format "City1 -> City2 -> ...")
            // For now, we'll use a heuristic: find alternate paths by trying different intermediate nodes
            
            // Try routing through each city as an intermediate point
            int alternateIndex = 1;
            for (int intermediate = 0; intermediate < numCities && alternateIndex < K; intermediate++)
            {
                if (intermediate == startNode || intermediate == endNode || !isValidCity(intermediate))
                    continue;
                
                // Calculate path: start -> intermediate -> end
                PathResult leg1 = calculateRoute(startNode, intermediate, false);
                PathResult leg2 = calculateRoute(intermediate, endNode, false);
                
                int totalDist = leg1.distance + leg2.distance;
                
                // Check if this is a valid alternative and different from already found paths
                if (totalDist < 999999 && totalDist > results[0].distance)
                {
                    bool isDuplicate = false;
                    for (int check = 0; check < alternateIndex; check++)
                    {
                        if (results[check].distance == totalDist)
                        {
                            isDuplicate = true;
                            break;
                        }
                    }
                    
                    if (!isDuplicate)
                    {
                        results[alternateIndex].distance = totalDist;
                        results[alternateIndex].pathString = leg1.pathString + " -> (via " + 
                                                             cities[intermediate].name + ") -> " + 
                                                             cities[endNode].name;
                        results[alternateIndex].isBlocked = leg1.isBlocked || leg2.isBlocked;
                        results[alternateIndex].hasTraffic = leg1.hasTraffic || leg2.hasTraffic;
                        alternateIndex++;
                    }
                }
            }
        }
        
        // Sort results by distance (bubble sort for simplicity)
        for (int i = 0; i < K - 1; i++)
        {
            for (int j = 0; j < K - i - 1; j++)
            {
                if (results[j].distance > results[j + 1].distance)
                {
                    RouteOption temp = results[j];
                    results[j] = results[j + 1];
                    results[j + 1] = temp;
                }
            }
        }
        
        // Update rankings
        for (int k = 0; k < K; k++)
            results[k].ranking = k + 1;
    }
};

class TrackingTable
{
private:
    static const int TABLE_SIZE = 50;
    ParcelLinkedList *table[TABLE_SIZE];

    int hashFunction(int id) { return id % TABLE_SIZE; }

public:
    TrackingTable()
    {
        for (int i = 0; i < TABLE_SIZE; i++)
            table[i] = new ParcelLinkedList();
    }

    void insert(Parcel *p)
    {
        int index = hashFunction(p->id);
        table[index]->append(p);
    }

    Parcel *search(int id)
    {
        int index = hashFunction(id);
        return table[index]->search(id);
    }
};

// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                   MODULE 4: USER MANAGEMENT & ADMIN TOOLS                    ║
// ║                           (Member 4 Responsibility)                          ║
// ╠═══════════════════════════════════════════════════════════════════════════════╣
// ║ ABSTRACTION: This module encapsulates user auth, riders, and file I/O        ║
// ║                                                                               ║
// ║ DATA STRUCTURES:                                                              ║
// ║   • LoginSystem - User authentication with linked list                       ║
// ║   • UserSession - Current user session data                                  ║
// ║   • Rider - Delivery rider with workload tracking                            ║
// ║                                                                               ║
// ║ INTERFACE FUNCTIONS:                                                          ║
// ║   • LoginSystem::authenticate() - Verify username/password                   ║
// ║   • LoginSystem::registerUser() - Add new user                               ║
// ║   • Rider::canAccept() - Check if rider can take parcel                      ║
// ║   • Rider::assignParcel() - Assign parcel to rider                           ║
// ║   • saveSystem() - Persist data to file                                      ║
// ║   • loadSystem() - Load data from file                                       ║
// ║                                                                               ║
// ║ FILE FORMAT: CSV with parcel fields (ID, source, dest, weight, etc.)         ║
// ║                                                                               ║
// ║ MENU OPTIONS: [10] Rider Mgmt, [11] Dashboard, [14] Save System              ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

void saveSystem(CityGraph &map, ParcelLinkedList &masterList)
{
    ofstream outFile("system_data.txt");
    
    if (!outFile.is_open())
    {
        cout << " Error: Could not save to file." << endl;
        return;
    }
    
    // Save parcels
    outFile << "=== PARCELS ===" << endl;
    ParcelNode* curr = masterList.head;
    while (curr)
    {
        Parcel* p = curr->data;
        outFile << p->id << ","
                << p->source << ","
                << p->destination << ","
                << p->weight << ","
                << p->priority << ","
                << p->status << ","
                << p->shippingCost << ","
                << p->isMissing << ","
                << p->warehouseStage << endl;
        curr = curr->next;
    }
    
    outFile << "=== END ===" << endl;
    outFile.close();
    
    cout << " System saved to system_data.txt" << endl;
}

void loadSystem(CityGraph &map, ParcelLinkedList &masterList, ParcelHeap &heap, CustomQueue &queue, TrackingTable &tracker)
{
    // 1. HARDCODED GRAPH DATA (Real-time Insertion)
    map.addCity(0, "Lahore");
    map.addCity(1, "Islamabad");
    map.addCity(2, "Karachi");
    map.addCity(3, "Rawalpindi");
    map.addCity(4, "Faisalabad"); 
    map.addCity(5, "Multan");
    map.addCity(6, "Peshawar");
    map.addCity(7, "Quetta");
    map.addCity(8, "Sialkot");
    map.addCity(9, "Gujranwala");

    // Road Network (Source, Dest, Weight, Status)
    map.addRoad(0, 1, 380); // LHR-ISL
    map.addRoad(1, 3, 20);  // ISL-RWP
    map.addRoad(0, 4, 180); // LHR-FSD
    map.addRoad(0, 9, 70);  // LHR-GUJ
    map.addRoad(9, 8, 50);  // GUJ-SKT
    map.addRoad(4, 5, 240); // FSD-MUL
    map.addRoad(5, 2, 900); // MUL-KHI
    map.addRoad(1, 6, 180); // ISL-PEW
    map.addRoad(5, 7, 600); // MUL-QTA
    map.addRoad(2, 7, 690); // KHI-QTA

    // 2. HARDCODED PARCEL DATA (Sample Data for Simulation)
    // Parcel(id, src, dest, weight, priority)
    Parcel *p1 = new Parcel(101, "Lahore", "Islamabad", 5, 1);
    Parcel *p2 = new Parcel(102, "Karachi", "Quetta", 12, 2);
    Parcel *p3 = new Parcel(103, "Multan", "Peshawar", 2, 3);

    // Manually insert into structures
    masterList.append(p1);
    tracker.insert(p1);
    heap.insert(p1);

    masterList.append(p2);
    tracker.insert(p2);
    heap.insert(p2);

    masterList.append(p3);
    tracker.insert(p3);
    heap.insert(p3);
}

// ==========================================
// LOGIN & SECURITY SYSTEM (IN-MEMORY)
// ==========================================
struct UserSession
{
    string username;
    string role;
};

// Simple User Node for runtime list
struct UserNode
{
    string username;
    string password;
    UserNode *next;
    UserNode(string u, string p) : username(u), password(p), next(nullptr) {}
};

class LoginSystem
{
private:
    UserNode *head;

public:
    LoginSystem() : head(nullptr)
    {
        // Pre-load default users into memory
        addUser("admin", "admin123");
        addUser("staff", "staff123");
    }

    void addUser(string u, string p)
    {
        UserNode *newNode = new UserNode(u, p);
        newNode->next = head;
        head = newNode;
    }

    bool validate(const string &username, const string &password)
    {
        UserNode *curr = head;
        while (curr) 
        {
            if (curr->username == username && curr->password == password)
                return true;
            curr = curr->next;
        }
        return false;
    }

    bool isUsernameTaken(const string &username)
    {
        UserNode *curr = head;
        while (curr)
        {
            if (curr->username == username)
                return true;
            curr = curr->next;
        }
        return false;
    }

    UserSession authenticate()
    {
        int choice;
        while (true)
        {
            printBrandHeader();
            cout << endl;
          
            cout << "                 LOGIN MENU                " << endl<<endl;
            cout << "     [1] Login as ADMIN                    " << endl;
            cout << "     [2] Login as STAFF                    " << endl;
            cout << "     [3] Create Staff Account              " << endl;
            cout << "     [0] Exit                              " << endl;
        
            choice = getValidInput("    Select: ");

            if (choice == 1)
            {
                string u, p;
                cout << "    Username: ";
                cin >> u;
                if (u == "0")
                    continue;
                cout << "    Password: ";
                cin >> p;
                if (u == "admin" && p == "admin123")
                {
                    cout << "\n    Admin login successful." << endl;
                    cin.ignore(INT_MAX, '\n');
                    return {u, "Admin"};
                }
                else
                {
                    cout << "\n    Login failed." << endl;
                }
            }
            else if (choice == 2)
            {
                string u, p;
                cout << "    Username: ";
                cin >> u;
                if (u == "0")
                    continue;
                cout << "    Password: ";
                cin >> p;
                if (validate(u, p))
                {
                    cout << "\n    Welcome, " << u << "." << endl;
                    cin.ignore(INT_MAX, '\n');
                    return {u, "Staff"};
                }
                else
                {
                    cout << "\n    Invalid login." << endl;
                }
            }
            else if (choice == 3)
            {
                string u, p;
                cout << endl;
                printTitle("NEW STAFF ACCOUNT");
                cout << " New Username: ";
                cin >> u;
                if (isUsernameTaken(u))
                {
                    cout << " Username already taken." << endl;
                    continue;
                }
                cout << " New Password: ";
                cin >> p;

                // Real-time insertion into user list
                addUser(u, p);
                cout << " Account created." << endl;
            }
            else if (choice == 0)
            {
                return {"", ""};
            }
            else
            {
                cout << " Invalid option." << endl;
            }
        }
    }
};

// ==========================================
// NEW: AUTOMATIC STATUS UPDATE MANAGER
// ==========================================
void autoUpdateStatuses(ParcelLinkedList &masterList)
{
    ParcelNode *curr = masterList.head;
    bool updated = false;
    time_t now = time(0);

    while (curr)
    {
        if (curr->data->status == "In Transit")
        {
            double elapsed = difftime(now, curr->data->dispatchTime);

            // Check if duration has passed
            if (elapsed >= curr->data->deliveryDuration)
            {
                updated = true;
                if (curr->data->willFail)
                {
                    curr->data->status = "Delivery Failed";
                    curr->data->addEvent("Delivery failed (Blocked Path).");
                    cout << " Parcel " << curr->data->id << ": Delivery failed." << endl;
                }
                else
                {
                    curr->data->status = "Delivered";
                    curr->data->addEvent("Delivered to " + curr->data->destination);
                    cout << " Parcel " << curr->data->id << ": Delivered." << endl;
                }
            }
        }
        curr = curr->next;
    }
    if (updated)
        printLine();
}

// ==========================================
// MAIN CONTROLLER
// ==========================================
int main()
{
    // Setup In-Memory Data Structures
    ParcelHeap sortingEngine;
    CityGraph mapEngine;
    TrackingTable tracker;
    CustomQueue shippingQueue;
    CustomStack undoStack;
    ParcelLinkedList masterList;
    
    // NEW: Enhanced Features
    Rider riders[10];
    int numRiders = 0;
    
    // Initialize some default riders
    riders[numRiders++] = Rider(1, "Ahmed", 5, 50);
    riders[numRiders++] = Rider(2, "Sara", 5, 50);
    riders[numRiders++] = Rider(3, "Ali", 5, 50);
    
    // Load Real-Time Data (No Files)
    loadSystem(mapEngine, masterList, sortingEngine, shippingQueue, tracker);

    LoginSystem auth;
    UserSession session = auth.authenticate();

    if (session.username == "")
    {
        cout << " Exiting system. Goodbye!" << endl;
        return 0;
    }

    int choice;
    do
    {
        // Clear screen for fresh display
        system("cls");
        
        // Run Auto-Update Check at start of loop
        autoUpdateStatuses(masterList);

        cout << endl;
        printBrandHeader();
        cout << "   USER: " << session.username << " (" << session.role << ")" << endl;

        printDoubleLine();
        cout << "  MAIN MENU" << endl;
        cout << endl << "  PARCEL OPERATIONS" << endl;
        cout << "  [1] New Parcel          [2] Track Parcel" << endl;
        
        cout << endl << "  TRUCK OPERATIONS" << endl;
        cout << "  [3] Load Truck          [4] Dispatch Truck       [5] Undo Load" << endl;
        
        cout << endl << "  ROUTING & NAVIGATION" << endl;
        cout << "  [6] Route Info          [7] K-Shortest Paths" << endl;
        
        cout << endl << "  WAREHOUSE MANAGEMENT" << endl;
        cout << "  [8] Priority Queue      [9] All Parcels" << endl;
        
        if (session.role == "Admin")
        {
            cout << endl << "  ADMIN TOOLS" << endl;
            cout << "  [10] Rider Management   [11] Dashboard          [12] Missing Parcels" << endl;
        }
        
        cout << endl << "  SYSTEM" << endl;
        cout << "  [13] Manual Update      [14] Save System        [0] Exit" << endl;
        printDoubleLine();

        choice = getValidInput("    Select option: ");

        switch (choice)
        {
        case 1: // New Parcel
        {
            printTitle("NEW PARCEL");
            int id, w, p, srcID, destID;
            string srcName, destName;

            id = getValidInput(" Enter Parcel ID (0 to Cancel): ");
            if (id == 0)
            {
                cout << " Cancelled." << endl;
                break;
            }

            if (tracker.search(id) != nullptr)
            {
                cout << " Error: ID already exists!" << endl;
                break;
            }

            cout << "\n" << " Select Source City:";
            mapEngine.printNetwork();
            while (true)
            {
                srcID = getValidInput(" Source City ID (-1 to Cancel): ");
                if (srcID == -1)
                    break;
                if (mapEngine.isValidCity(srcID))
                {
                    srcName = mapEngine.getCityName(srcID);
                    break;
                }
                else
                    cout << " Invalid ID." << endl;
            }
            if (srcID == -1)
            {
                cout << " Cancelled." << endl;
                break;
            }

            mapEngine.printDestinationsFrom(srcID);
            while (true)
            {
                destID = getValidInput(" Destination City ID (-1 to Cancel): ");
                if (destID == -1)
                    break;
                if (mapEngine.isValidCity(destID) && destID != srcID)
                {
                    destName = mapEngine.getCityName(destID);
                    break;
                }
                else
                    cout << " Invalid ID." << endl;
            }
            if (destID == -1)
            {
                cout << " Cancelled." << endl;
                break;
            }

            w = getValidInput(" Weight (kg): ");
            p = getValidInput(" Priority (1=High, 2=Med, 3=Low): ");

            cout << "\n" << " Calculating route..." << endl;
            PathResult route = mapEngine.calculateRoute(srcID, destID, false);

            // --- NEW WARNING LOGIC ---
            bool doom = false;
            int duration = 0;

            if (route.isBlocked || route.distance >= 999999)
            {
                cout << " Warning: Path is BLOCKED." << endl;
                cout << " Parcel may fail if sent." << endl;
                cout << " Continue? (1=Yes, 0=No): ";
                int confirm = getValidInput("");
                if (confirm == 0)
                    break;
                doom = true;
                duration = 10; // Fail quickly (10 seconds)
            }
            else if (route.hasTraffic)
            {
                cout << " Traffic detected." << endl;
                cout << " Parcel may be late." << endl;
                duration = route.distance;
            }
            else
            {
                cout << " Route: " << route.pathString << endl;
                cout << " Distance: " << route.distance << " km" << endl;
                duration = route.distance;
            }

            cout << " Estimated time: " << duration << " seconds" << endl;

            Parcel *newParcel = new Parcel(id, srcName, destName, w, p);
            newParcel->addEvent("Route: " + route.pathString);

            // Set Simulation Flags
            newParcel->willFail = doom;
            newParcel->deliveryDuration = duration;

            sortingEngine.insert(newParcel);
            tracker.insert(newParcel);
            masterList.append(newParcel);

            cout << endl << " Parcel registered." << endl;
            cout << " Cost: Rs:" << newParcel->shippingCost << endl;
            break;
        }
        case 2: // Track Parcel
        {
            printTitle("TRACK PARCEL");
            int searchID = getValidInput(" Enter Tracking ID (0 to Cancel): ");
            if (searchID == 0)
                break;
            Parcel *p = tracker.search(searchID);
            if (p)
            {
                cout << endl << " Parcel found:" << endl;
                p->printRow();
                cout << "\n" << " History:" << endl;
                cout << p->historyLog << endl;

                if (p->status == "In Transit")
                {
                    double elapsed = difftime(time(0), p->dispatchTime);
                    cout << "\n Transit time: " << elapsed << "s / " << p->deliveryDuration << "s" << endl;
                }
            }
            else
            {
                cout << endl << " Not found." << endl;
            }
            break;
        }
        case 3: // Load Truck
        {
            printTitle("LOAD TRUCK");
            if (shippingQueue.isFull())
            {
                cout << " Truck is full." << endl;
                break;
            }
            Parcel *p = sortingEngine.extractMin();
            if (p)
            {
                cout << " Loading parcel:" << endl;
                p->printRow();
                p->status = "Loaded on Truck";
                p->addEvent("Loaded onto truck.");
                shippingQueue.enqueue(p);
                undoStack.push(p);
                cout << " Status: Loaded on Truck" << endl;
            }
            else
            {
                cout << " No parcels to load." << endl;
            }
            break;
        }
        case 4: // Dispatch Truck
        {
            printTitle("DISPATCH TRUCK");
            if (shippingQueue.isEmpty())
            {
                cout << " Truck is empty." << endl;
            }
            else
            {
                cout << " Dispatching " << shippingQueue.getSize() << " parcels..." << endl;

                time_t now = time(0);
                while (!shippingQueue.isEmpty())
                {
                    Parcel *p = shippingQueue.dequeue();
                    p->status = "In Transit";
                    p->dispatchTime = now;
                    p->addEvent("Dispatch: Truck departed.");

                    cout << "    - Parcel " << p->id << " (" << p->destination << "): "
                         << "In Transit" << " (ETA: " << p->deliveryDuration << "s)" << endl;
                }
                undoStack.clear();
                cout << endl << " Truck dispatched." << endl;
            }
            break;
        }
        case 5: // Undo Load
        {
            if (session.role != "Admin")
            {
                cout << " Admin access required." << endl;
                break;
            }
            if (undoStack.isEmpty())
                cout << " Nothing to undo." << endl;
            else
            {
                Parcel *p = undoStack.pop();
                shippingQueue.removeLast();
                p->status = "Processing";
                p->addEvent("Undo: Operation reversed.");
                sortingEngine.insert(p);
                cout << " Undo: Parcel ID " << p->id << endl;
            }
            break;
        }
        case 6: // Route Info
        {
            printTitle("ROUTE INFO");
            mapEngine.printNetwork();
            int start = getValidInput("\n Start City ID: ");
            int end = getValidInput(" End City ID:   ");
            PathResult ideal = mapEngine.calculateRoute(start, end, true);
            PathResult actual = mapEngine.calculateRoute(start, end, false);

            cout << endl;
            if (actual.isBlocked || actual.distance >= 999999)
            {
                cout << " Route is BLOCKED." << endl;
                cout << " Ideal path: " << ideal.pathString << endl;
            }
            else if (actual.hasTraffic)
            {
                cout << " Heavy traffic." << endl;
                cout << " Path: " << actual.pathString << " (May be late)" << endl;
            }
            else
            {
                cout << " Route: " << actual.pathString << endl;
            }
            break;
        }
        case 8: // Priority Queue View
        {
            printTitle("PRIORITY QUEUE");
            sortingEngine.displayPriorityQueue();
            
            if (!sortingEngine.isEmpty())
            {
                cout << "\n Priority Queue Statistics:" << endl;
                cout << " - Total parcels in queue: " << sortingEngine.getSize() << endl;
                
                // Count by priority
                int high = 0, med = 0, low = 0;
                ParcelNode* curr = masterList.head;
                while (curr)
                {
                    if (curr->data->status == "Processing")
                    {
                        if (curr->data->priority == 1) high++;
                        else if (curr->data->priority == 2) med++;
                        else if (curr->data->priority == 3) low++;
                    }
                    curr = curr->next;
                }
                cout << " - High Priority: " << high << endl;
                cout << " - Medium Priority: " << med << endl;
                cout << " - Low Priority: " << low << endl;
            }
            break;
        }
        case 13: // Manual Update
        {
            printTitle("MANUAL UPDATE");
            int id = getValidInput(" Parcel ID: ");
            Parcel *p = tracker.search(id);
            if (!p)
            {
                cout << " Not found." << endl;
                break;
            }
            cout << " Current: " << p->status << endl;
            cout << " [1] Delivered\n [2] Failed\n";
            int statChoice = getValidInput(" Select: ");
            if (statChoice == 1)
            {
                p->status = "Delivered";
                p->addEvent("Manual: Delivered.");
            }
            if (statChoice == 2)
            {
                p->status = "Delivery Failed";
                p->addEvent("Manual: Failed.");
            }
            break;
        }
        case 14: // Save System
        {
            saveSystem(mapEngine, masterList);
            break;
        }
        case 9: // All Parcels
        {
            printTitle("ALL PARCELS");
            ParcelNode *curr = masterList.head;
            while (curr)
            {
                curr->data->printRow();
                curr = curr->next;
            }
            break;
        }
        case 0:
        {
            saveSystem(mapEngine, masterList);
            cout << "\n Exiting... Goodbye!" << endl;
            break;
        }
        case 7: // K-Shortest Paths
        {
            if (session.role != "Admin")
            {
                cout << " Admin access required." << endl;
                break;
            }
            printTitle("K-SHORTEST PATHS");
            mapEngine.printNetwork();
            int start = getValidInput(" Start City ID: ");
            int end = getValidInput(" End City ID: ");
            
            RouteOption routes[3];
            mapEngine.calculateKShortestPaths(start, end, routes, 3);
            
            cout << "\n Alternative Routes:" << endl;
            printLine();
            for (int i = 0; i < 3; i++)
            {
                if (routes[i].distance < INT_MAX)
                {
                    cout << " Route #" << routes[i].ranking << ": " << routes[i].pathString << endl;
                    cout << "   Distance: " << routes[i].distance << " km";
                    if (routes[i].isBlocked) cout << " (BLOCKED)";
                    if (routes[i].hasTraffic) cout << " (TRAFFIC)";
                    cout << endl << endl;
                }
            }
            printLine();
            break;
        }
        case 10: // Rider Management
        {
            if (session.role != "Admin")
            {
                cout << " Admin access required." << endl;
                break;
            }
            printTitle("RIDER MANAGEMENT");
            cout << " [1] View All Riders" << endl;
            cout << " [2] Add New Rider" << endl;
            cout << " [3] Assign Parcel to Rider" << endl;
            cout << " [0] Back" << endl;
            
            int riderChoice = getValidInput(" Select: ");
            
            if (riderChoice == 1)
            {
                cout << "\n Rider Fleet:" << endl;
                printLine();
                cout << "| " << left << setw(4) << "ID"
                     << "| " << setw(15) << "NAME"
                     << "| " << setw(12) << "LOAD"
                     << "| " << setw(15) << "WEIGHT"
                     << "| " << setw(10) << "STATUS" << " |" << endl;
                printLine();
                for (int i = 0; i < numRiders; i++)
                {
                    riders[i].printRow();
                }
                printLine();
            }
            else if (riderChoice == 2)
            {
                if (numRiders >= 10)
                {
                    cout << " Maximum riders reached." << endl;
                    break;
                }
                int rid = getValidInput(" Rider ID: ");
                string rname;
                cout << " Rider Name: ";
                cin >> rname;
                riders[numRiders++] = Rider(rid, rname, 5, 50);
                cout << " Rider added." << endl;
            }
            else if (riderChoice == 3)
            {
                int pid = getValidInput(" Parcel ID: ");
                Parcel* p = tracker.search(pid);
                if (!p)
                {
                    cout << " Parcel not found." << endl;
                    break;
                }
                
                // Find available rider
                bool assigned = false;
                for (int i = 0; i < numRiders; i++)
                {
                    if (riders[i].canAccept(p->weight))
                    {
                        riders[i].assignParcel(p->weight);
                        p->addEvent("Assigned to Rider: " + riders[i].name);
                        cout << " Assigned to Rider " << riders[i].name << endl;
                        assigned = true;
                        break;
                    }
                }
                if (!assigned)
                    cout << " No available riders." << endl;
            }
            break;
        }
        case 11: // Dashboard
        {
            if (session.role != "Admin")
            {
                cout << " Admin access required." << endl;
                break;
            }
            printTitle("DASHBOARD");
            double dashRevenue = 0.0;
            int dashDelivered = 0;
            int missingCount = 0;
            int inTransit = 0;
            ParcelNode *curr = masterList.head;
            while (curr)
            {
                if (curr->data->status == "Delivered")
                {
                    dashRevenue += curr->data->shippingCost;
                    dashDelivered++;
                }
                if (curr->data->isMissing)
                    missingCount++;
                if (curr->data->status == "In Transit")
                    inTransit++;
                curr = curr->next;
            }
            
            // Rider utilization
            int ridersAvailable = 0;
            for (int i = 0; i < numRiders; i++)
            {
                if (riders[i].isAvailable)
                    ridersAvailable++;
            }
            
            cout << "\n === FINANCIAL ===" << endl;
            cout << left << setw(35) << " Revenue:" << "Rs:" << fixed << setprecision(2) << dashRevenue << endl;
            
            cout << "\n === PARCELS ===" << endl;
            cout << left << setw(35) << " Parcels Delivered:" << dashDelivered << endl;
            cout << left << setw(35) << " Parcels In Transit:" << inTransit << endl;
            cout << left << setw(35) << " Missing Parcels:" << missingCount << endl;
            
            cout << "\n === RIDERS ===" << endl;
            cout << left << setw(35) << " Total Riders:" << numRiders << endl;
            cout << left << setw(35) << " Available Riders:" << ridersAvailable << endl;
            
            cout << "\n === PRIORITY QUEUE ===" << endl;
            cout << left << setw(35) << " Parcels in Queue:" << sortingEngine.getSize() << endl;
            if (!sortingEngine.isEmpty())
            {
                Parcel* nextParcel = sortingEngine.peek();
                cout << left << setw(35) << " Next to Load:" 
                     << "Parcel #" << nextParcel->id 
                     << " (Priority " << nextParcel->priority << ")" << endl;
            }
            
            printLine();
            break;
        }
        case 12: // Missing Parcels
        {
            if (session.role != "Admin")
            {
                cout << " Admin access required." << endl;
                break;
            }
            printTitle("MISSING PARCELS REPORT");
            
            cout << " [1] Mark Parcel as Missing" << endl;
            cout << " [2] View Missing Parcels" << endl;
            cout << " [0] Back" << endl;
            
            int missingChoice = getValidInput(" Select: ");
            
            if (missingChoice == 1)
            {
                int pid = getValidInput(" Parcel ID to mark missing: ");
                Parcel* p = tracker.search(pid);
                if (p)
                {
                    p->isMissing = true;
                    p->status = "Missing";
                    p->addEvent("ALERT: Parcel marked as MISSING.");
                    cout << " Parcel #" << pid << " marked as MISSING." << endl;
                }
                else
                {
                    cout << " Parcel not found." << endl;
                }
            }
            else if (missingChoice == 2)
            {
                cout << "\n Missing Parcels:" << endl;
                printLine();
                int count = 0;
                ParcelNode* curr = masterList.head;
                while (curr)
                {
                    if (curr->data->isMissing)
                    {
                        curr->data->printRow();
                        count++;
                    }
                    curr = curr->next;
                }
                if (count == 0)
                    cout << " No missing parcels." << endl;
                else
                    cout << "\n Total Missing: " << count << endl;
                printLine();
            }
            break;
        }
        default:
            cout << "\n Invalid option." << endl;
        }

        if (choice != 0)
        {
            cout << "\n Press Enter to continue...";
            cin.ignore(INT_MAX, '\n');
            cin.get();
        }

    } while (choice != 0);
    return 0;
}
